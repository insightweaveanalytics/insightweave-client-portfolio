# InsightWeave Analytics Client Portfolio

A static, responsive portfolio site for InsightWeave Analytics, with two independent demonstrations included in the package.

## Preview locally

Open `index.html` in a browser. The invoice demo also includes a local browser workspace; its run instructions are in `projects/invoice-processing/README.md`. The support-ticket NLP project notebook can be uploaded to Google Colab with its CSV; instructions are in `projects/support-ticket-nlp/README.md`.

## Publish

This is a static site suitable for GitHub Pages. Upload the contents of this folder to a repository and enable Pages for the branch/folder where `index.html` lives. The project links are relative paths, so keep the included `projects` directory alongside the site.

## Contact

The site includes insightweaveanalytics@gmail.com as a public contact email and links to the public InsightWeave Analytics LinkedIn profile.

## Accuracy notes

- Demonstration projects are labeled as independent portfolio work using synthetic data.
- The invoice demo handles labeled text files only; PDF/image OCR is not included.
- The NLP demo is a prototype and is not presented as validated for real customer conversations.
- The L&T internship entry uses only the confirmed details: role, dates, Google Colab, and exposure to machine-learning and NLP models.
- The portfolio includes only the experience and project details confirmed for public use.


