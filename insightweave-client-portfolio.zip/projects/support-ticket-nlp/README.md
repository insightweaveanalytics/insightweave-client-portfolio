# Support Ticket Triage with NLP

**InsightWeave Analytics | Independent portfolio demo**

A reproducible machine-learning/NLP project that classifies short support messages by topic and sentiment. The dataset is generated specifically for this portfolio exercise and contains no real customer records or employer data.

## Project contents

- `synthetic_support_tickets.csv` — 720 generated examples across six topics and three sentiment labels
- `InsightWeave_Support_Ticket_NLP_Demo.ipynb` — Colab-ready notebook with data checks, TF-IDF, logistic-regression baselines, evaluation, and sample predictions
- `requirements.txt` — Python dependencies for local use

## Run in Google Colab

1. Upload the notebook and CSV to Google Colab.
2. Upload `synthetic_support_tickets.csv` to the Colab session files, or mount Drive and update `DATA_PATH`.
3. Run the notebook from top to bottom.

## Methods

The notebook trains two separate text-classification pipelines: topic classification and sentiment classification. Each uses TF-IDF word and bigram features with logistic regression. A stratified held-out split and per-class precision, recall, F1, and confusion matrices support basic evaluation.

## Responsible use and limitations

All data is synthetic and intentionally simple. The demo does not establish performance on real conversations, and generated wording can make this task easier than production data. Predictions are examples for human review, not automated decisions. Real use would need authorized representative data, privacy safeguards, stronger validation, and monitoring.

## Portfolio summary

Built an end-to-end NLP demonstration that generates a labeled dataset, prepares text features, trains topic and sentiment classifiers, evaluates held-out predictions, and surfaces errors for review.
